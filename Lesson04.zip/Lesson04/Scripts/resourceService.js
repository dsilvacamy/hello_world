var app = angular.module("serviceApp",['ngResource']);
app.provider('EmployeeService', function() {
    this.$get = ['$resource', function($resource) {
	//$resource - $http.get and it will get the details from the file
      var EmployeeService = $resource('data/employees-test.json', {}, {
        update: {
		//$http- put method is used to update the object
          method: 'PUT'
        }
      })

      return EmployeeService;
    }];
  });
/*
saveBooks: function($params) 
{      
return $http({ 
		url: base_url + 'json/save_book',
        method: "POST",  
		data: $params,    
		})
*/