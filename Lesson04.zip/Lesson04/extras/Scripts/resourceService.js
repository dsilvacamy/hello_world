var app = angular.module("serviceApp",['ngResource']);
app.provider('EmployeeService', function() {
    this.$get = ['$resource', function($resource) {
      var EmployeeService = $resource('data/employees-test.json', {}, {
        update: {
          method: 'PUT'
        }
      })

      return EmployeeService;
    }];
  });
