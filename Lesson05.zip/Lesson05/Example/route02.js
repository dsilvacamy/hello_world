var app = angular.module('routeApp',['ngRoute']);
app.config(function($routeProvider,$locationProvider){
		$routeProvider
		.when('/',                            
		{
			template:'<h1>Please select a service</h1>'
		})
		.when('/view1',{
				controller: 'AccController',
				templateUrl:'partials/createAcc.html'
		})
		.when('/view2',{
				controller: 'MainController',
				templateUrl: 'partials/viewDetails.html'
		})
		.when('/view3',{
				templateUrl: 'partials/Success.html'
		})
		.otherwise({
			redirectTo:'/'
		})
		$locationProvider.html5Mode(false);
});

app.controller("AccController",function($scope,$location){
	$scope.rate = "8.5";
	$scope.name = "Ashish";
	$scope.address = "";
	$scope.phNo = "";
	$scope.loadPage=function(page){
			$location.replace();// clears the history
			$location.url('/'+page);
		}
});

app.controller("MainController",function($scope,$location){
	$scope.accounts = [
	{"accId":"101","custName":"Kunal","balance":"89788"},
	{"accId":"102","custName":"Akash","balance":"1212"},
	{"accId":"103","custName":"Ronald","balance":"23233"},
	{"accId":"106","custName":"Allen","balance":"52346"}
	];
	
});